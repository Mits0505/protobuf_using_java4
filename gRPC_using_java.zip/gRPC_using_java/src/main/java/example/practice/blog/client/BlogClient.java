package example.practice.blog.client;

import com.proto.blog.*;
import io.grpc.*;

public class BlogClient {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello I am a Blog Client");

        runClient();
    }

    private static void runClient() throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost",50052)
                .usePlaintext()
                .build();

       // Create a Blog.
        System.out.println("Creating Blog... ");

        BlogServiceGrpc.BlogServiceBlockingStub blogClient = BlogServiceGrpc.newBlockingStub(channel);
        CreateBlogResponse createBlogResponse = blogClient.createBlog(CreateBlogRequest.newBuilder()
                                               .setBlog(Blog.newBuilder()
                                                            .setAuthorId("Mitali")
                                                            .setTitle("Mitali Blog")
                                                            .setContent("My First Blog..").build()).build());

        System.out.println("Created Blog.. ");
        System.out.println(createBlogResponse.toBuilder().toString());

        // Read a Blog.
        System.out.println("");
        System.out.println("Reading Blog... ");

        String blogId = createBlogResponse.getBlog().getId();
        ReadBlogResponse readBlogResponse = blogClient.readBlog(ReadBlogRequest.newBuilder()
                                           .setBlogId(blogId).build());

        System.out.println("Read Blog... ");
        System.out.println(readBlogResponse.toBuilder().toString());

       /* System.out.println("Reading Blog with non existing id... ");
        ReadBlogResponse readBlogNotFound = blogClient.readBlog(ReadBlogRequest.newBuilder()
                .setBlogId("5e8ae1b144f95a5990bd0ab2").build());*/

       // Update a Blog.
        System.out.println("");
        System.out.println("Updating Blog... ");
        UpdateBlogResponse updateBlogResponse = blogClient.updateBlog(UpdateBlogRequest.newBuilder()
                .setBlog(Blog.newBuilder()
                             .setId(blogId)
                             .setAuthorId("Lokesh")
                             .setTitle("New Blog")
                             .setContent("New Blog Content")
                             .build())
                .build());
        System.out.println("Updated Blog... ");
        System.out.println(updateBlogResponse.toBuilder().toString());

        // Delete a Blog.
        System.out.println("");
        System.out.println("Deleting Blog... ");
        DeleteBlogResponse deleteBlogResponse = blogClient.deleteBlog(DeleteBlogRequest.newBuilder()
                .setBlogId(blogId)
                .build());
        System.out.println("Deleted Blog... ");
        System.out.println(deleteBlogResponse.toBuilder().toString());

       /* System.out.println("Reading blog after deletion... ");
        readBlogResponse = blogClient.readBlog(ReadBlogRequest.newBuilder()
                .setBlogId(blogId).build());*/

       // Lists the blog.
       System.out.println("");
       System.out.println("List the blogs... ");
       blogClient.listBlog(ListBlogRequest.newBuilder()
                                          .build()).forEachRemaining(listBlogResponse ->{
           System.out.println(listBlogResponse.getBlog().toString());
       });

        System.out.println("Shutting down channel");
        channel.shutdown();
    }
}
