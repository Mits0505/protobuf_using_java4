package example.practice.blog.server;

import example.practice.greet.server.GreetServiceImpl;
import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.protobuf.services.ProtoReflectionService;

import java.io.IOException;

public class BlogServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Hello Blog Server!");

        Server server = ServerBuilder.forPort(50052)
                                     .addService(new BlogServiceImpl())
                                     .addService(ProtoReflectionService.newInstance())
                                     .build();
        server.start();

        /* With the help of below code, when we try to close the application, server
         * will also shutdown. And server.awaitTermination() will complete.
         */

        Runtime.getRuntime().addShutdownHook(new Thread( () -> {
         System.out.println("Received Shutdown Request..");
         server.shutdown();
         System.out.println("Successfully stopped the server.");
        }));

        // In gRPC, this server needs to be blocking for the main thread, so we do server.awaitTermination().
        server.awaitTermination(); // If we don't do this, then our server will start and program will finish.
    }
}
