package example.practice.blog.server;

import com.mongodb.client.*;
import com.mongodb.client.result.DeleteResult;
import com.proto.blog.*;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;
import org.bson.Document;
import org.bson.types.ObjectId;

import static com.mongodb.client.model.Filters.eq;


public class BlogServiceImpl extends BlogServiceGrpc.BlogServiceImplBase {
    private MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
    private MongoDatabase mongoDatabase = mongoClient.getDatabase("mydb");
    private MongoCollection<Document> collection = mongoDatabase.getCollection("blog");

    @Override
    public void createBlog(CreateBlogRequest request, StreamObserver<CreateBlogResponse> responseObserver) {

        System.out.println("Received Create Blog request");

        Blog blog = request.getBlog();
        Document document = new Document("author_id",blog.getAuthorId())
                                              .append("title", blog.getTitle())
                                              .append("content", blog.getContent());

        System.out.println("Inserting Blog...");
        // We insert or create the document in MongoDB.
        collection.insertOne(document);

        // We retrieve MongoDB generated ID.
        String id = document.getObjectId("_id").toString();
        System.out.println("Inserted Blog: "+id);

       /* CreateBlogResponse blogResponse = CreateBlogResponse.newBuilder()
                .setBlog(Blog.newBuilder()
                        .setAuthorId(blog.getAuthorId())
                        .setTitle(blog.getTitle())
                        .setContent(blog.getContent())
                        .setId(id).build()).build();*/

        CreateBlogResponse blogResponse = CreateBlogResponse.newBuilder()
                .setBlog(blog.toBuilder().setId(id).build())
                .build();

        responseObserver.onNext(blogResponse);
        responseObserver.onCompleted();

        System.out.println();
    }

    @Override
    public void readBlog(ReadBlogRequest request, StreamObserver<ReadBlogResponse> responseObserver) {
        System.out.println("");
        System.out.println("Received Read Blog request");

        String blog_id = request.getBlogId();

        System.out.println("Searching for a Blog");
        Document result = null;
        try {
             result = collection.find(eq("_id", new ObjectId(blog_id))).first();
        }catch (Exception e){
            responseObserver.onError(Status.NOT_FOUND
                    .withDescription("Blog with the corresponding ID is not found")
                    .augmentDescription(e.getLocalizedMessage())
                    .asRuntimeException());
        }
       if(result == null) {
           System.out.println("Blog not found..");
           responseObserver.onError(Status.NOT_FOUND
                   .withDescription("Blog with the corresponding ID is not found")
                   .asRuntimeException());
       }else{
           System.out.println("Blog Found, sending response.");
           Blog blog = documentToBlog(result);
           responseObserver.onNext(ReadBlogResponse.newBuilder().setBlog(blog).build());
           responseObserver.onCompleted();
       }

    }

    @Override
    public void updateBlog(UpdateBlogRequest request, StreamObserver<UpdateBlogResponse> responseObserver) {
        System.out.println("");
        System.out.println("Received Update Blog request");

        String blog_id = request.getBlog().getId();

        System.out.println("Searching for a blog, so that we can update it. ");
        Document result = null;
        try {
            result = collection.find(eq("_id", new ObjectId(blog_id))).first();
        }catch (Exception e){
            responseObserver.onError(Status.NOT_FOUND
                    .withDescription("Blog with the corresponding ID is not found")
                    .augmentDescription(e.getLocalizedMessage())
                    .asRuntimeException());
        }
        if(result == null) {
            System.out.println("Blog not found..");
            responseObserver.onError(Status.NOT_FOUND
                    .withDescription("Blog with the corresponding ID is not found")
                    .asRuntimeException());
        }else{
            Document replacement = new Document("author_id",request.getBlog().getAuthorId())
                                                                   .append("title",request.getBlog().getTitle())
                                                                   .append("content", request.getBlog().getContent())
                                                                   .append("_id",new ObjectId(blog_id));

            System.out.println("Replacing blog in database.");
            collection.replaceOne(eq("_id", result.getObjectId("_id")), replacement);

            System.out.println("Replaced, sending a response.");
            responseObserver.onNext(UpdateBlogResponse.newBuilder()
                    .setBlog(documentToBlog(replacement)).build());
            responseObserver.onCompleted();
        }
    }

    @Override
    public void deleteBlog(DeleteBlogRequest request, StreamObserver<DeleteBlogResponse> responseObserver) {
        System.out.println("");
        System.out.println("Received Delete Blog Request");

        String blog_id = request.getBlogId();

        DeleteResult deleteResult = null;
        try {
            deleteResult = collection.deleteOne(eq("_id", new ObjectId(blog_id)));
        }catch (Exception e){
            responseObserver.onError(Status.NOT_FOUND
                    .withDescription("Blog with the corresponding ID is not found")
                    .augmentDescription(e.getLocalizedMessage())
                    .asRuntimeException());
        }
        if(deleteResult == null) {
            System.out.println("Blog not found..");
            responseObserver.onError(Status.NOT_FOUND
                    .withDescription("Blog with the corresponding ID is not found")
                    .asRuntimeException());
        }else{
            System.out.println("Blog is deleted.");
            responseObserver.onNext(DeleteBlogResponse.newBuilder().
                                                               setBlogId(blog_id).build());
            responseObserver.onCompleted();
        }

    }

    @Override
    public void listBlog(ListBlogRequest request, StreamObserver<ListBlogResponse> responseObserver) {

        System.out.println("");
        System.out.println("Received List Blog request");

        collection.find().forEach(document -> responseObserver.onNext(ListBlogResponse.newBuilder()
                                                                                      .setBlog(documentToBlog(document))
                                                                                      .build()));
        responseObserver.onCompleted();
    }

    private Blog documentToBlog(Document result) {
        return Blog.newBuilder()
                .setAuthorId(result.getString("author_id"))
                .setTitle(result.getString("title"))
                .setContent(result.getString("content"))
                .setId(result.getObjectId("_id").toString())
                .build();
    }
}
