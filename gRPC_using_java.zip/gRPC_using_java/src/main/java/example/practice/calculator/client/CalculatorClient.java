package example.practice.calculator.client;

import com.proto.calculator.*;
import com.proto.greet.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class CalculatorClient {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello I am a gRPC Calculator Client");

        runClient();
    }

    private static void runClient() throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost",50052)
                .usePlaintext()
                .build();

        // Unary.
        doSquareErrorCall(channel);
        //doSum(channel);
        // Streaming server.
        //doPrimeNumberDecompositions(channel);
        // Client Streaming.
        //doAverage(channel);
        // BIDI Streaming.
        //findMax(channel);

        System.out.println("Shutting down channel");
        channel.shutdown();
    }

    private static void findMax(ManagedChannel channel) throws InterruptedException {
        // Creating a async stub, since client is streaming.

        System.out.println("Find current max between all the numbners sent.");
        CalculatorServiceGrpc.CalculatorServiceStub asyncStub = CalculatorServiceGrpc.newStub(channel);

        // It is required for async programming, so that we can wait for the server's response.
        CountDownLatch latch = new CountDownLatch(1);

        // findMaximum rpc call.
        StreamObserver<FindMaximumRequest> requestStreamObserver = asyncStub.findMaximum(new StreamObserver<FindMaximumResponse>(){

            @Override
            public void onNext(FindMaximumResponse value) {
                System.out.println("Response received from the server");
                System.out.println(value);
            }

            @Override
            public void onError(Throwable t) {
              latch.countDown();
            }

            @Override
            public void onCompleted() {
             System.out.println("Server has finished sending the response.");
             latch.countDown();
            }
        });
        Arrays.asList(1,5,3,6,2,20).forEach(number -> {
            System.out.println("Sending number: "+number);
            requestStreamObserver.onNext(FindMaximumRequest.newBuilder()
                    .setNumber(number)
                    .build());
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        requestStreamObserver.onCompleted();
        latch.await();
    }

    private static void doAverage(ManagedChannel channel) throws InterruptedException {
        // Creating a async stub, since client is streaming.

        System.out.println("Compute Average rpc call.");
        CalculatorServiceGrpc.CalculatorServiceStub asyncStub = CalculatorServiceGrpc.newStub(channel);

        // It is required for async programming, so that we can wait for the server's response.
        CountDownLatch countDownLatch = new CountDownLatch(1);

        // Calling computeAverage rpc.
        StreamObserver<ComputeAverageRequest> requestStreamObserver = asyncStub.computeAverage(new StreamObserver<ComputeAverageResponse>(){

            @Override
            public void onNext(ComputeAverageResponse value) {
                System.out.println("Response has been received from the server.");
                System.out.println(value);
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {
                System.out.println("Server has completed sending the response.");
                countDownLatch.countDown();
            }
        });

        // Send First number.
        requestStreamObserver.onNext(ComputeAverageRequest.newBuilder()
                                                          .setNumber(1).build());
        // Send Second number.
        requestStreamObserver.onNext(ComputeAverageRequest.newBuilder()
                .setNumber(2).build());

        // Send Third number.
        requestStreamObserver.onNext(ComputeAverageRequest.newBuilder()
                .setNumber(3).build());

        // Send Fourth number.
        requestStreamObserver.onNext(ComputeAverageRequest.newBuilder()
                .setNumber(4).build());

        requestStreamObserver.onCompleted();
        countDownLatch.await(100L, TimeUnit.SECONDS);
    }

    private static void doPrimeNumberDecompositions(ManagedChannel channel) {
        // Created a stub.
        CalculatorServiceGrpc.CalculatorServiceBlockingStub blockingStub = CalculatorServiceGrpc.newBlockingStub(channel);

        // Created Request.
        PrimeNumberDecompositionRequest request = PrimeNumberDecompositionRequest.newBuilder()
                                                                                 .setNumber(120)
                                                                                 .build();
        // Called rpc service PrimeNumberDecomposition.
        System.out.println();
        System.out.println("Calling PrimeNumberDecompositionRequest rpc for number "+request.getNumber());

       blockingStub.primeNumberDecomposition(request).forEachRemaining(primeNumberDecompositionResponse -> {
           System.out.println(primeNumberDecompositionResponse.toString());
       });
    }

    private static void doSum(ManagedChannel channel) {
        // Created a stub.
        CalculatorServiceGrpc.CalculatorServiceBlockingStub blockingStub = CalculatorServiceGrpc.newBlockingStub(channel);

        // Created SumRequest.
        SumRequest request = SumRequest.newBuilder()
                                       .setNumber1(3)
                                       .setNumber2(10)
                                       .build();
       // Called rpc service sum.
        System.out.println();
        System.out.println("Calling sum rpc for numbers "+request.getNumber1()+" and "+request.getNumber2());

        SumResponse sumResponse = blockingStub.sum(request);

        System.out.println(sumResponse.toString());
    }

    private static void doSquareErrorCall(ManagedChannel channel) {
        CalculatorServiceGrpc.CalculatorServiceBlockingStub blockingStub = CalculatorServiceGrpc.newBlockingStub(channel);
        int number = -1;
        try {
            blockingStub.squareRoot(SquareRootRequest.newBuilder()
                    .setNumber(number).build());
        }catch (StatusRuntimeException e){
            System.out.println("Got an exception fo square root!");
            e.printStackTrace();
        }
    }
}
