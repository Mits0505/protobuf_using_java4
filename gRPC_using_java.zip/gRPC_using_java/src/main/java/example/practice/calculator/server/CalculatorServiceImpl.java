package example.practice.calculator.server;

import com.proto.calculator.*;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

public class CalculatorServiceImpl extends CalculatorServiceGrpc.CalculatorServiceImplBase {
    @Override
    public void squareRoot(SquareRootRequest request, StreamObserver<SqaureRootResponse> responseObserver) {
        int number = request.getNumber();
        if(number > 0) {
            double squareRoot = Math.sqrt(number);
            responseObserver.onNext(SqaureRootResponse.newBuilder()
                    .setSquareRoot(squareRoot).build());
            responseObserver.onCompleted();
        }else{
            // We construct the exception.
            responseObserver.onError(
                    Status.INVALID_ARGUMENT
                          .withDescription("The number being sent is not positive.")
                            .augmentDescription("Number sent: "+number)
                          .asRuntimeException()
            );
        }
    }

    @Override
    public void sum(SumRequest request, StreamObserver<SumResponse> responseObserver) {
       // Read the request.
        int number1 = request.getNumber1();
        int number2 = request.getNumber2();

       // Perform operation.
        int sum = number1 + number2;

        // Created response.
        SumResponse sumResponse = SumResponse.newBuilder()
                                             .setSumResult(sum).build();

        // Sending response.
        responseObserver.onNext(sumResponse);

        // Completing the call.
        responseObserver.onCompleted();

    }

    @Override
    public void primeNumberDecomposition(PrimeNumberDecompositionRequest request, StreamObserver<PrimeNumberDecompositionResponse> responseObserver) {
        // Reading request.
        int number = request.getNumber();

        int k = 2;
        try {
            while (number > 1) {
                if (number % k == 0) {
                    PrimeNumberDecompositionResponse response = PrimeNumberDecompositionResponse.newBuilder()
                            .setPrimeNumber(k).build();
                    responseObserver.onNext(response);
                    number /= k;

                    Thread.sleep(1000);
                } else {
                    k += 1;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            responseObserver.onCompleted();
        }
    }

    @Override
    public StreamObserver<ComputeAverageRequest> computeAverage(StreamObserver<ComputeAverageResponse> responseObserver) {
       StreamObserver<ComputeAverageRequest> requestObserver = new StreamObserver<ComputeAverageRequest>() {
           int sum = 0;
           int numberOfValues = 0;
           @Override
           public void onNext(ComputeAverageRequest value) {
               sum +=value.getNumber();
               numberOfValues++;
           }

           @Override
           public void onError(Throwable t) {

           }

           @Override
           public void onCompleted() {
              double average = (double) sum/numberOfValues;
              responseObserver.onNext(ComputeAverageResponse.newBuilder()
                                                            .setAverage(average).buildPartial());
              responseObserver.onCompleted();
           }
       };
        return requestObserver;
    }

    @Override
    public StreamObserver<FindMaximumRequest> findMaximum(StreamObserver<FindMaximumResponse> responseObserver) {
        StreamObserver<FindMaximumRequest> requestObserver = new StreamObserver<FindMaximumRequest>(){

            int max =0;
            @Override
            public void onNext(FindMaximumRequest value) {
                int number = value.getNumber();
                if(number>max){
                    responseObserver.onNext(FindMaximumResponse.newBuilder()
                                                               .setMaximumNumber(number).build());
                    max = number;
                }else{
                    // Do nothing.
                    // This is the example where we are sending less responses from the server than the client requests.
                }
            }

            @Override
            public void onError(Throwable t) {
                responseObserver.onCompleted();
            }

            @Override
            public void onCompleted() {
              responseObserver.onCompleted();
            }
        };
        return requestObserver;
    }
}
